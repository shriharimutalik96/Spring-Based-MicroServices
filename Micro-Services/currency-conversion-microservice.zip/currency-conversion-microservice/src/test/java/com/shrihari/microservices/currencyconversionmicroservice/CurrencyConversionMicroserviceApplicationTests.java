package com.shrihari.microservices.currencyconversionmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyConversionMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
